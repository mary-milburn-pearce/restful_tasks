import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';
import { AngularWaitBarrier } from 'blocking-proxy/built/lib/angular_wait_barrier';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  tasks: object;
  newTask: object;
  editTask: object;
  addResults: object;
  editResults: object;
  deleteResults: object;
  showEdit: boolean;
  selectedTask: object;
  title = 'Restful API'; 
  constructor(private _httpService: HttpService){}

  ngOnInit() {
    this.newTask = { title: "", description: "" }
    this.editTask = { id: "", title: "", description: "" }
    this.addResults = { content: "" }
    this.editResults = { content: "" }
    this.deleteResults = { content: "" }
    this.showEdit = false;
    this.getTasksFromService();
  }
  getTasksFromService() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our data!", data);
      this.tasks = data;
    })
  }
  onSubmitAdd(newTask) { 
    console.log(`Click event called with: ${newTask}`);
    let observable = this._httpService.postToServer(newTask);
    observable.subscribe(data => {
      console.log("Returned:", data);
      if (data['errors']) this.addResults['content']=data['message']
    });
    this.newTask = { title: "", description: "" };
    this.addResults = { content: "" };
  }
  onSubmitEdit() {
    let id = this.editTask['id'];
    console.log("onSubmit: ", "Id:", id, this.editTask);
    let observable = this._httpService.putToServer(id, this.editTask);
    observable.subscribe(data => {
      console.log("Returned:", data);
      if (data['errors']) {
        this.editResults['content']=data['message']
      } else {
        this.showEdit = false;
        this.editTask = { id: "", title: "", description: "" };
        this.editResults = { content: "" };
      }
    });
  }
  onSubmitDelete(task) {
    let id = task['_id'];
    let observable = this._httpService.deleteFromServer(task);
    observable.subscribe(data => {
      console.log("Returned:", data);
      if (data['errors']) this.deleteResults['content']=data['message'];
      this.getTasksFromService();
    });
  }
  onButtonClickGetAll() {
    this.getTasksFromService();
  }
  onButtonClickEdit(task) {
    console.log('Edit button clicked for', task)
    this.editTask = {id: task['_id'], title: task['title'], description: task['description'] };
    this.showEdit = true;
  }
  onButtonClickDelete(task) {
    this.onSubmitDelete(task)
  }
  onButtonClickShow(task) {
    this.selectedTask = task;
  }

}


