import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';
import { Key } from 'protractor';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  tasks: object;
  details: object;
  //tasks: any;
  showForm: boolean;
  title = 'app';
  constructor(private _httpService: HttpService){}

  ngOnInit() {
    this.showForm = false;
    // this.getTasksFromService()
  }
  getTasksFromService() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our data!", data);
      this.tasks = data;
    })
  }
  // onButtonShowPostForm() {
    
  // }
  // PostTask(task): void { 
  //   console.log(`Click event is working with num param: ${task}`);
  //   let tempData = {title: "get post working", description: "this could take quite a while!"};
  //   let observable = this._httpService.postToServer(tempData);
  //   observable.subscribe(data => console.log("Got our data!", data));
  // }
  onButtonClickGetAll() {
    this.getTasksFromService();
  }
  onButtonClickShowDetails(task) {
    this.details = task;
  }

}


